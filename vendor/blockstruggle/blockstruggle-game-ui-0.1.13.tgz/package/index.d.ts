import type { ComponentType } from "react";

export interface NinjaMiniGameProps {
	readonly apiPath?: string;
	readonly fetcher?: typeof fetch;
	readonly initialMatchId?: string;
	readonly onExit: () => void;
	readonly onSignIn: () => void;
}

export declare const NinjaMiniGame: ComponentType<NinjaMiniGameProps>;
